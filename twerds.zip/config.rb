
css_dir = "assets/css" # by Compass.app 
sass_dir = "styling" # by Compass.app 
images_dir = "images" # by Compass.app 
output_style = :compressed # by Compass.app 
relative_assets = true # by Compass.app 
line_comments = true # by Compass.app 
sass_options = {:debug_info=>false} # by Compass.app 
sourcemap = false # by Compass.app 